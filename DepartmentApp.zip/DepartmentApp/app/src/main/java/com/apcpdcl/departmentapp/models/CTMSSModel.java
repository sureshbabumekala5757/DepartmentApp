package com.apcpdcl.departmentapp.models;

public class CTMSSModel {
    private String subname;
    private String subcode;

//    public CTMSSModel(String subname, String subcode) {
//        this.subname = subname;
//        this.subcode = subcode;
//    }

    public String getsubname() {
        return subname;
    }

    public void setsubname(String subname) {
        this.subname = subname;
    }

    public String getsubcode() {
        return subcode;
    }

    public void setsubcode(String subcode) {
        this.subcode = subcode;
    }
}
