package com.apcpdcl.departmentapp.models;

public class ComplaintIdModel {
    private String complaint_id;

    public String getComplaint_id() {
        return complaint_id;
    }

    public void setComplaint_id(String complaint_id) {
        this.complaint_id = complaint_id;
    }
}
