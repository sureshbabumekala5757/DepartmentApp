package com.apcpdcl.departmentapp.interfaces;
/**
 * Created by Haseen
 * on 25-04-2018.
 */
public interface IUpdateList {
    void updateList(String id);
}
