package com.apcpdcl.departmentapp.model;

public class ReconnectionSrcModel {
    private String service_No;

    public ReconnectionSrcModel(String service_No) {
        this.service_No = service_No;
    }

    public String getService_No() {
        return service_No;
    }

    public void setService_No(String service_No) {
        this.service_No = service_No;
    }
}
