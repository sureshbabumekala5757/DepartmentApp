package com.apcpdcl.departmentapp.models;

public class DigitalModel {

    private String Digital_Amt;
    private String Digital_count;
    private String Cash_Amount;
    private String Cash_count;
    private String SEC_Name;
    private String DIV_Name;
    private String ERO_Name;

    public String getDigital_Amt() {
        return Digital_Amt;
    }

    public void setDigital_Amt(String Digital_Amt) {
        this.Digital_Amt = Digital_Amt;
    }

    public String getDigital_count() {
        return Digital_count;
    }

    public void setDigital_count(String Digital_count) {
        this.Digital_count = Digital_count;
    }

    public String getCash_Amount() {
        return Cash_Amount;
    }

    public void setCash_Amount(String Cash_Amount) {
        this.Cash_Amount = Cash_Amount;
    }

    public String getCash_count() {
        return Cash_count;
    }

    public void setCash_count(String Cash_count) {
        this.Cash_count = Cash_count;
    }

    public String getSEC_Name() {
        return SEC_Name;
    }

    public void setSEC_Name(String SEC_Name) {
        this.SEC_Name = SEC_Name;
    }

    public String getDIV_Name() {
        return DIV_Name;
    }

    public void setDIV_Name(String DIV_Name) {
        this.DIV_Name = DIV_Name;
    }

    public String getERO_Name() {
        return ERO_Name;
    }

    public void setERO_Name(String ERO_Name) {
        this.ERO_Name = ERO_Name;
    }
}
