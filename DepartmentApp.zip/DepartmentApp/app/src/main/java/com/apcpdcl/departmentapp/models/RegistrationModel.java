package com.apcpdcl.departmentapp.models;

/**
 * Created by Haseen
 * on 24-03-2018.
 */

public class RegistrationModel {
    private String Regno;

    public RegistrationModel(String regno) {
        Regno = regno;
    }

    public String getRegno() {
        return Regno;
    }

    public void setRegno(String regno) {
        Regno = regno;
    }
}
