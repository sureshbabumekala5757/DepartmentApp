package com.apcpdcl.departmentapp.models;

public class CTMFeedersModel {
    private String fdrname;
    private String fdrcode;

//    public CTMFeedersModel(String fdrname, String fdrcode) {
//        this.fdrname = fdrname;
//        this.fdrcode = fdrcode;
//    }

    public String getfdrname() {
        return fdrname;
    }

    public void setfdrname(String fdrname) {
        this.fdrname = fdrname;
    }

    public String getfdrcode() {
        return fdrcode;
    }

    public void setfdrcode(String fdrcode) {
        this.fdrcode = fdrcode;
    }
}
