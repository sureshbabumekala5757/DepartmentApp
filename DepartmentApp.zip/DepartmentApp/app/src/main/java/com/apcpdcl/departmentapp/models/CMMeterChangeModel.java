package com.apcpdcl.departmentapp.models;

public class CMMeterChangeModel {

    private String AAO_STATUS;
    private String AE_STATUS;
    private String NMTCHDT;
    private String AMOUNT;
    private String STATUS;
    private String BILLDATE ;
    private String SCTYPE;
    private String LMCODE ;
    private String PHONENUM ;
    private String DOORNUM  ;
    private String POLENUM;
    private String FDRCD;
    private String DTRCD;
    private String CAT;
    private String CNAME;
    private String USCNO;

    public String getAAO_STATUS() {
        return AAO_STATUS;
    }

    public void setAAO_STATUS(String AAO_STATUS) {
        this.AAO_STATUS = AAO_STATUS;
    }

    public String getAE_STATUS() {
        return AE_STATUS;
    }

    public void setAE_STATUS(String AE_STATUS) {
        this.AE_STATUS = AE_STATUS;
    }

    public String getNMTCHDT() {
        return NMTCHDT;
    }

    public void setNMTCHDT(String NMTCHDT) {
        this.NMTCHDT = NMTCHDT;
    }

    public String getAMOUNT() {
        return AMOUNT;
    }

    public void setAMOUNT(String AMOUNT) {
        this.AMOUNT = AMOUNT;
    }

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }


    public String getSCTYPE() {
        return SCTYPE;
    }

    public void setSCTYPE(String SCTYPE) {
        this.SCTYPE = SCTYPE;
    }

    public String getPOLENUM() {
        return POLENUM;
    }

    public void setPOLENUM(String POLENUM) {
        this.POLENUM = POLENUM;
    }

    public String getFDRCD() {
        return FDRCD;
    }

    public void setFDRCD(String FDRCD) {
        this.FDRCD = FDRCD;
    }

    public String getDTRCD() {
        return DTRCD;
    }

    public void setDTRCD(String DTRCD) {
        this.DTRCD = DTRCD;
    }

    public String getCAT() {
        return CAT;
    }

    public void setCAT(String CAT) {
        this.CAT = CAT;
    }

    public String getCNAME() {
        return CNAME;
    }

    public void setCNAME(String CNAME) {
        this.CNAME = CNAME;
    }

    public String getUSCNO() {
        return USCNO;
    }

    public void setUSCNO(String USCNO) {
        this.USCNO = USCNO;
    }

    public String getBILLDATE() {
        return BILLDATE;
    }

    public void setBILLDATE(String BILLDATE) {
        this.BILLDATE = BILLDATE;
    }

    public String getLMCODE() {
        return LMCODE;
    }

    public void setLMCODE(String LMCODE) {
        this.LMCODE = LMCODE;
    }

    public String getPHONENUM() {
        return PHONENUM;
    }

    public void setPHONENUM(String PHONENUM) {
        this.PHONENUM = PHONENUM;
    }

    public String getDOORNUM() {
        return DOORNUM;
    }

    public void setDOORNUM(String DOORNUM) {
        this.DOORNUM = DOORNUM;
    }
}
