package com.apcpdcl.departmentapp.models;

public class NotificationModel {
}
