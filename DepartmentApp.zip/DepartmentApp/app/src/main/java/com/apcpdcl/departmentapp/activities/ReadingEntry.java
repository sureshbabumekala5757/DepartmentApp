package com.apcpdcl.departmentapp.activities;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.apcpdcl.departmentapp.R;
import com.apcpdcl.departmentapp.utils.Utility;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ReadingEntry extends AppCompatActivity {
    private LinearLayout reading_ll,kwh_Kvah_reading_ll,agl_reading_ll;
    private String readingType;
    private TextView toolbar_title;
    @BindView(R.id.reading_date)
    EditText reading_date;
    private int minutes = -1;
    private int mYear = -1;
    private int mMonth = -1;
    private int mDay = -1;
    private boolean isRestore = false;
    private LinearLayout commanLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reading_entry);
        ButterKnife.bind(this);
        toolbar_title = findViewById(R.id.toolbar_title);
        kwh_Kvah_reading_ll = findViewById(R.id.kwh_Kvah_reading_ll);
        agl_reading_ll = findViewById(R.id.agl_reading_ll);
        reading_ll = findViewById(R.id.reading_ll);

        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        if (bd != null) {
            readingType = (String) bd.get("ReadingType");
            toolbar_title.setText(readingType+ " Reading Entry");
        }

        // Remove all the existing TextViews
        kwh_Kvah_reading_ll.removeAllViews();
        agl_reading_ll.removeAllViews();

        int numberOfFields = 10; // The given number of fields to generate

        if(!readingType.equalsIgnoreCase("Agriculture 3-Ph")) {
            // Loop through the desired number of times
            for (int i = 0; i < numberOfFields; i++) {
                // Create a new TextView
                TextView textView = new TextView(this);
                textView.setText("Feeder " + (i + 1));
                textView.setId(i + 1); // Set a unique ID for the TextView

                // Create a new EditText
                EditText editText = new EditText(this);
                editText.setHint("Enter " + readingType + " value");
                editText.setId(i + 100); // Set a unique ID for the EditText

                // Add the TextView and EditText to the LinearLayout
                kwh_Kvah_reading_ll.addView(textView);
                kwh_Kvah_reading_ll.addView(editText);
            }
            int lvnumberofField = 2;
            for (int i = 1; i <= lvnumberofField; i++) {
                // Create a new TextView
                TextView lvTV = new TextView(this);
                lvTV.setText("LV " + (i));
                lvTV.setId(i + 1); // Set a unique ID for the TextView

                // Create a new EditText
                EditText lvET = new EditText(this);
                lvET.setHint("Enter lv value");
                lvET.setId(i + 100); // Set a unique ID for the EditText

                // Add the TextView and EditText to the LinearLayout
                kwh_Kvah_reading_ll.addView(lvTV);
                kwh_Kvah_reading_ll.addView(lvET);
            }
            // Refresh the parent view
            kwh_Kvah_reading_ll.invalidate();
        }else{
            // Loop through the desired number of times
            for (int i = 0; i < numberOfFields; i++) {
                // Create a new TextView
                TextView feederTv = new TextView(this);
                feederTv.setText("Feeder " + i);
                feederTv.setId(i + 1); // Set a unique ID for the TextView
                agl_reading_ll.addView(feederTv);
                for (int j = 0; j < 3; j++) {
                    // Create a new TextView
                    TextView textView = new TextView(this);
                    textView.setText("Spell " + j);
                    textView.setId(j + 1); // Set a unique ID for the TextView

                    // Create a new EditText
                    EditText editText = new EditText(this);
                    editText.setHint("Enter Opening reading value");
                    editText.setId(j + 100); // Set a unique ID for the EditText

                    // Create a new EditText
                    EditText kvahET = new EditText(this);
                    kvahET.setHint("Enter Closing reading value");
                    kvahET.setId(j + 100); // Set a unique ID for the EditText

                    // Create a new EditText
                    EditText spellDurhET = new EditText(this);
                    spellDurhET.setHint("Enter spell duration (hours) value");
                    spellDurhET.setId(j + 100); // Set a unique ID for the EditText

                    // Add the TextView and EditText to the LinearLayout
                    agl_reading_ll.addView(textView);
                    agl_reading_ll.addView(editText);
                    agl_reading_ll.addView(kvahET);
                    agl_reading_ll.addView(spellDurhET);
                }

            }
            agl_reading_ll.invalidate();
        }
        /**************************************************************************************/
//        Calendar calendar = Calendar.getInstance();
//        int year = calendar.get(Calendar.YEAR);
//        int month = calendar.get(Calendar.MONTH) + 1; // Note: Months are zero-based, so add 1
//        int day = calendar.get(Calendar.DAY_OF_MONTH);
//
//        String currentDate = year + "-" + month + "-" + day;
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate = dateFormat.format(currentDate);
        reading_date.setText(formattedDate);
        /**************************************************************************************/
    }
    public void submitBtn (View view) {
        // Get a reference to the LinearLayout
        if(!readingType.equalsIgnoreCase("Agriculture 3-Ph")) {
            commanLayout = kwh_Kvah_reading_ll;
        }else {
            commanLayout = agl_reading_ll;
        }

        // Loop through the child views of the LinearLayout
                for (int i = 0; i < commanLayout.getChildCount(); i++) {
                    if (commanLayout.getChildAt(i) instanceof TextView) {
                        // Cast the child view to an TextView
                        TextView textView = (TextView) commanLayout.getChildAt(i);

                        // Get the value of the EditText
                        String textValue = textView.getText().toString();

                        // Do something with the value, such as storing it in a list or array
                        Log.d("textView", "textView Value: " + textValue);
                    }
                    // Check if the child view is an EditText
                    if (commanLayout.getChildAt(i) instanceof EditText) {
                        // Cast the child view to an EditText
                        EditText editText = (EditText) commanLayout.getChildAt(i);

                        // Get the value of the EditText
                        String value = editText.getText().toString();

                        // Do something with the value, such as storing it in a list or array
                        Log.d("EditText", "Value: " + value);
                    }
                }
    }

    DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            // TODO Auto-generated method stub

            if (isRestore) {

                isRestore = false;
            } else {
                if (dayOfMonth < 10) {
                    reading_date.setText("0" + dayOfMonth + "-" + Utility.getMonthFormat(monthOfYear + 1) + "-" + year);
                } else {
                    reading_date.setText(dayOfMonth + "-" + Utility.getMonthFormat(monthOfYear + 1) + "-" + year);
                }
                mYear = year;
                mMonth = monthOfYear + 1;
                mDay = dayOfMonth;

            }
            //setDuration();
        }

    };

    @OnClick(R.id.reading_date)
    void openOutageDatePicker() {
        final Calendar c = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, date, c.get(Calendar.YEAR),
                c.get(Calendar.MONTH), c.get(Calendar.DATE));
        datePickerDialog.getDatePicker().setMaxDate(c.getTimeInMillis());
        datePickerDialog.getDatePicker().setMinDate(Calendar.DATE);
        datePickerDialog.show();
        //setDuration();
    }

}