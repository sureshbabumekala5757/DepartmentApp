package com.apcpdcl.departmentapp.models;

public class CounterModel {

    private String Section;
    private String Sec_SCS;
    private String Sec_AMT;
    private String ERO_AMT;
    private String ERO_SCS;
    private String SubDiv_AMT;
    private String SubDiv_SCS;
    private String DIV_Name;
    private String ERO_Name;

    public String getSection() {
        return Section;
    }

    public void setSection(String Section) {
        this.Section = Section;
    }

    public String getSec_SCS() {
        return Sec_SCS;
    }

    public void setSec_SCS(String Sec_SCS) {
        this.Sec_SCS = Sec_SCS;
    }

    public String getSec_AMT() {
        return Sec_AMT;
    }

    public void setSec_AMT(String Sec_AMT) {
        this.Sec_AMT = Sec_AMT;
    }

    public String getERO_AMT() {
        return ERO_AMT;
    }

    public void setERO_AMT(String ERO_AMT) {
        this.ERO_AMT = ERO_AMT;
    }

    public String getERO_SCS() {
        return ERO_SCS;
    }

    public void setERO_SCS(String ERO_SCS) {
        this.ERO_SCS = ERO_SCS;
    }

    public String getSubDiv_AMT() {
        return SubDiv_AMT;
    }

    public void setSubDiv_AMT(String SubDiv_AMT) {
        this.SubDiv_AMT = SubDiv_AMT;
    }

    public String getSubDiv_SCS() {
        return SubDiv_SCS;
    }

    public void setSubDiv_SCS(String SubDiv_SCS) {
        this.SubDiv_SCS = SubDiv_SCS;
    }

    public String getDIV_Name() {
        return DIV_Name;
    }

    public void setDIV_Name(String DIV_Name) {
        this.DIV_Name = DIV_Name;
    }

    public String getERO_Name() {
        return ERO_Name;
    }

    public void setERO_Name(String ERO_Name) {
        this.ERO_Name = ERO_Name;
    }
}
