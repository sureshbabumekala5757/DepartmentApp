package com.apcpdcl.departmentapp.utils;

/**
 * Created by haseen
 * on 6/12/17.
 */

public class APIConstants {
    public enum REQUEST_TYPE {
        GET, POST, MULTIPART_GET, MULTIPART_POST, DELETE, PUT, PATCH
    }
}
