package com.apcpdcl.departmentapp.models;

public class AbstractModel {

    private String DSL_amount;
    private String DNS_amount ;
    private String DTotal_count;
    private String DNS_count;
    private String DTotal_Amount;
    private String CheckReading_Count;
    private String DSL_count;

    public String getDSL_amount() {
        return DSL_amount;
    }

    public void setDSL_amount(String DSL_amount) {
        this.DSL_amount = DSL_amount;
    }

    public String getDNS_amount() {
        return DNS_amount;
    }

    public void setDNS_amount(String DNS_amount) {
        this.DNS_amount = DNS_amount;
    }

    public String getDTotal_count() {
        return DTotal_count;
    }

    public void setDTotal_count(String DTotal_count) {
        this.DTotal_count = DTotal_count;
    }

    public String getDNS_count() {
        return DNS_count;
    }

    public void setDNS_count(String DNS_count) {
        this.DNS_count = DNS_count;
    }

    public String getDTotal_Amount() {
        return DTotal_Amount;
    }

    public void setDTotal_Amount(String DTotal_Amount) {
        this.DTotal_Amount = DTotal_Amount;
    }

    public String getCheckReading_Count() {
        return CheckReading_Count;
    }

    public void setCheckReading_Count(String CheckReading_Count) {
        this.CheckReading_Count = CheckReading_Count;
    }

    public String getDSL_count() {
        return DSL_count;
    }

    public void setDSL_count(String DSL_count) {
        this.DSL_count = DSL_count;
    }
}
