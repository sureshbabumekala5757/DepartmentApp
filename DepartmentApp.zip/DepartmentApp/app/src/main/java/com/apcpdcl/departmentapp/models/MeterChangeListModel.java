package com.apcpdcl.departmentapp.models;

public class MeterChangeListModel {

    private String KVAHUNITS;
    private String KWHUNITS;
    private String NEWMTRNO;
    private String OLDMTRNO;
    private String MTRCHGDT;
    private String USCNO;
    private String MTCHSLIP;
    private String REJREMARKS;
    private String REJDATE;

    public String getKVAHUNITS() {
        return KVAHUNITS;
    }

    public void setKVAHUNITS(String KVAHUNITS) {
        this.KVAHUNITS = KVAHUNITS;
    }

    public String getKWHUNITS() {
        return KWHUNITS;
    }

    public void setKWHUNITS(String KWHUNITS) {
        this.KWHUNITS = KWHUNITS;
    }

    public String getNEWMTRNO() {
        return NEWMTRNO;
    }

    public void setNEWMTRNO(String NEWMTRNO) {
        this.NEWMTRNO = NEWMTRNO;
    }

    public String getOLDMTRNO() {
        return OLDMTRNO;
    }

    public void setOLDMTRNO(String OLDMTRNO) {
        this.OLDMTRNO = OLDMTRNO;
    }

    public String getMTRCHGDT() {
        return MTRCHGDT;
    }

    public void setMTRCHGDT(String MTRCHGDT) {
        this.MTRCHGDT = MTRCHGDT;
    }

    public String getUSCNO() {
        return USCNO;
    }

    public void setUSCNO(String USCNO) {
        this.USCNO = USCNO;
    }

    public String getMTCHSLIP() {
        return MTCHSLIP;
    }

    public void setMTCHSLIP(String MTCHSLIP) {
        this.MTCHSLIP = MTCHSLIP;
    }

    public String getREJREMARKS() {
        return REJREMARKS;
    }

    public void setREJREMARKS(String REJREMARKS) {
        this.REJREMARKS = REJREMARKS;
    }

    public String getREJDATE() {
        return REJDATE;
    }

    public void setREJDATE(String REJDATE) {
        this.REJDATE = REJDATE;
    }
}
