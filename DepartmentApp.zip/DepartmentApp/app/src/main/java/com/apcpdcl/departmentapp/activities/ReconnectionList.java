package com.apcpdcl.departmentapp.activities;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.apcpdcl.departmentapp.R;
import com.apcpdcl.departmentapp.adapters.ComplaintsListAdapter;
import com.apcpdcl.departmentapp.adapters.ReconnectionListAdapter;
import com.apcpdcl.departmentapp.interfaces.IUpdateList;
import com.apcpdcl.departmentapp.model.ReconnectionSrcModel;
import com.apcpdcl.departmentapp.models.ComplaintModel;
import com.apcpdcl.departmentapp.shared.AppPrefs;
import com.apcpdcl.departmentapp.utils.Utility;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ReconnectionList extends AppCompatActivity implements IUpdateList {
    @BindView(R.id.lv_reconnection)
    ListView lv_reconnection;
    @BindView(R.id.et_search)
    EditText et_search;
    @BindView(R.id.tv_no_data)
    TextView tv_no_data;
    @BindView(R.id.iv_search)
    ImageView iv_search;
    @BindView(R.id.rl_search)
    RelativeLayout rl_search;

    private ArrayList<ReconnectionSrcModel> reconnectionSrcModel;
    private ArrayList<String> reconnectionSrcArrList = new ArrayList<>();
    private ReconnectionListAdapter reconnectionListAdapter;
    public ProgressDialog pDialog;
    public Toolbar mToolbar;
    private String sectionCode, userId;
    private static IUpdateList iUpdateList;
    public static IUpdateList getInstance() {
        return iUpdateList;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reconnection_list);
        iUpdateList = this;
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        ButterKnife.bind(this);

        sectionCode = AppPrefs.getInstance(getApplicationContext()).getString("SECTIONCODE", "");
        userId = AppPrefs.getInstance(getApplicationContext()).getString("USERID", "");
        String usc = "654321000";
        for(int i=0; i<9; i++)
            reconnectionSrcArrList.add(usc+i);

        setListData();
//        if (Utility.isNetworkAvailable(this)) {
//            pDialog.show();
//            pDialog.setMessage("Please wait...");
//            pDialog.setCancelable(false);
//            //getComplaints();
//            JSONObject requestObj = new JSONObject();
//            try {
//                requestObj.put("bname", userId);
//            } catch (Exception e) {
//
//            }
//        } else {
//            Utility.showCustomOKOnlyDialog(this,
//                    Utility.getResourcesString(this,
//                            R.string.no_internet));
//        }
    }
    /* *
     *Get Reconnection List
     * */
    private void getReconnectionServ(JSONObject requestObjVal) {
        AsyncHttpClient client = new AsyncHttpClient();
        client.setTimeout(50000);
        HttpEntity entity;
        try {
            entity = new StringEntity(requestObjVal.toString());
            BasicHeader[] headers = new BasicHeader[]{new BasicHeader("Authorization", "Basic " + AppPrefs.getInstance(getApplicationContext()).getString("USER_AUTH", ""))};
            client.post(this, "https://apcpcdcl-test-k5qoqm5y.it-cpi012-rt.cfapps.ap21.hana.ondemand.com/http/DepartmentalApp/SAPISU/ComplaintList/DEV", headers, entity, "application/json", new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(String responseStr) {
                    Utility.showLog("onSuccess", responseStr);
                    if (pDialog != null && pDialog.isShowing()) {
                        pDialog.dismiss();
                    }
                    try {
                        JSONObject responseObj = new JSONObject(responseStr);
                        responseObj = responseObj.getJSONObject("response");
                        String status = responseObj.getString("success");
                        if (status.equalsIgnoreCase("True")) {
                            JSONArray dataArr = responseObj.getJSONArray("data");
//                            complaintIdArrList = new ArrayList<>();
//                            if (dataArr.length() > 0) {
//                                for (int i = 0; i < dataArr.length(); i++) {
//                                    JSONObject comIDObj = dataArr.getJSONObject(i);
//                                    complaintIdArrList.add(comIDObj.getString("complaint_id"));
//                                }
//                                if (complaintIdArrList.size() > 0) {
//                                    setListData();
//                                } else {
//                                    if (pDialog != null && pDialog.isShowing()) {
//                                        pDialog.dismiss();
//                                    }
//                                    tv_no_data.setVisibility(View.VISIBLE);
//                                    lv_reg.setVisibility(View.GONE);
//                                    rl_search.setVisibility(View.GONE);
//                                }
//                            }
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Throwable error, String content) {
                    Utility.showLog("error", error.toString());
                    if (pDialog != null && pDialog.isShowing()) {
                        pDialog.dismiss();
                    }
                    Utility.showCustomOKOnlyDialog(ReconnectionList.this, error.getMessage());
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }
    //Set data to List
    private void setListData() {
        reconnectionListAdapter = new ReconnectionListAdapter(this, reconnectionSrcArrList);
        lv_reconnection.setAdapter(reconnectionListAdapter);
        implementsSearch();
    }

    //IMPLEMENT SEARCH
    private void implementsSearch() {
        et_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (reconnectionListAdapter != null)
                    reconnectionListAdapter.getFilter().filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


    }

    @Override
    public void updateList(String id) {
        for (int i = 0; i < reconnectionSrcArrList.size(); i++) {
            if (id.equalsIgnoreCase(reconnectionSrcArrList.get(i))) {
                reconnectionSrcArrList.remove(i);
                if (reconnectionSrcArrList.size() > 0) {
                    reconnectionListAdapter.notifyDataSetChanged();
                } else {
                    tv_no_data.setVisibility(View.VISIBLE);
                    lv_reconnection.setVisibility(View.GONE);
                }
                break;
            }
        }
    }
}