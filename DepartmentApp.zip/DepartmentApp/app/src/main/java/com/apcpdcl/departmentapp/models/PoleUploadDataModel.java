package com.apcpdcl.departmentapp.models;

public class PoleUploadDataModel {
    private String sUserName;
    private String sSectionCode;
    private String sDistributionCode;
    private String sDtrCode;
    private String sPoleCode;
    private String sPoleUscnodata;
    private String sDate;

    public String getsUserName() {
        return sUserName;
    }

    public void setsUserName(String sUserName) {
        this.sUserName = sUserName;
    }

    public String getsDtrCode() {
        return sDtrCode;
    }

    public void setsDtrCode(String sDtrCode) {
        this.sDtrCode = sDtrCode;
    }

    public String getsSectionCode() {
        return sSectionCode;
    }

    public void setsSectionCode(String sSectionCode) {
        this.sSectionCode = sSectionCode;
    }

    public String getsDistributionCode() {
        return sDistributionCode;
    }

    public void setsDistributionCode(String sDistributionCode) {
        this.sDistributionCode = sDistributionCode;
    }

    public String getsPoleCode() {
        return sPoleCode;
    }

    public void setsPoleCode(String sPoleCode) {
        this.sPoleCode = sPoleCode;
    }

    public String getsPoleUscnodata() {
        return sPoleUscnodata;
    }

    public void setsPoleUscnodata(String sPoleUscnodata) {
        this.sPoleUscnodata = sPoleUscnodata;
    }

    public String getsDate() {
        return sDate;
    }

    public void setsDate(String sDate) {
        this.sDate = sDate;
    }
}
